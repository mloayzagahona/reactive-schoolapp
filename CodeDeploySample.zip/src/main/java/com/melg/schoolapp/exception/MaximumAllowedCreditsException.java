package com.melg.schoolapp.exception;

public class MaximumAllowedCreditsException extends Exception {}
