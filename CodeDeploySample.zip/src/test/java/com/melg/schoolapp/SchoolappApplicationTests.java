package com.melg.schoolapp;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SchoolappApplicationTests {

	@Test
	  @DisplayName("Spring Context Load")
	void contextLoads() {
	}

}
